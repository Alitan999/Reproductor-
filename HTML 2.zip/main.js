document.getElementById('playBtn').addEventListener('click', function() {
    var audio = document.getElementById('audio');
    audio.play();
});

document.getElementById('pauseBtn').addEventListener('click', function() {
    var audio = document.getElementById('audio');
    audio.pause();
});